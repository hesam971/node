const mongoose = require('mongoose');

const db = mongoose.connect('mongo config').
then(() => {console.log('databse connected')}).
catch((err) => {throw err});

module.exports = db;